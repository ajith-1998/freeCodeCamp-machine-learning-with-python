def add_time(*args):
    length=len(args);
    tt='';
    if(length==3):
        start = args[0];
        duration = args[1];
        day= args[2];
        global noDay;
        tday='';
        day=day.capitalize();
        days={0:"Sunday", 1:"Monday", 2:"Tuesday", 3:"Wednesday", 4:"Thusday", 5:"Friday", 6:"Saturday"};
        for x in days:
            if(day==days[x]):
                noDay=x;
        tili = [];
        durli= [];
        tili = start;
        sti1=tili.split(':');
        bhr=int(sti1[0]);
        sti2=sti1[1].split(' ');
        bmin=int(sti2[0]);
        bses=sti2[1];
        ases="AM"
        if(bses=="PM"):
            bhr=bhr+12;
        durli=duration;
        deli1=durli.split(':')
        dhr= int(deli1[0]);
        dmin= int(deli1[1]);
        addedmin= bmin+dmin;
        temp1=0
        if(addedmin>=60):
            temp1=addedmin//60;
            addedmin=addedmin%60;
        addedhr=temp1+bhr+dhr;
        temp3=0;
        if(addedhr>=24):
            temp3=addedhr//24;
            addedhr=addedhr%24;
        if(addedhr>11):
            if((addedhr>11)and(addedhr!=0)):
                ases="PM";
            else:
                ases="AM";
            addedhr=addedhr-12;
        noDay=noDay+temp3;
        if(noDay>=7):
            noDay=noDay%7;
        for x in days:
            if(x==noDay):
                tday=days[x];
        if(addedhr==0):
            addedhr=12;
        ah=str(addedhr);
        am=str(addedmin).zfill(2);
        if(temp3==0):
            new_t=ah+':'+am+' '+ases+", "+tday;
        if(temp3==1):
            new_t= ah+':'+am+' '+ases+", "+tday+ " (next day)";
        if(temp3>1):
            temp3=str(temp3);
            new_t=ah+':'+am+' '+ases+", "+tday+" ("+temp3+" days later)";
        new_time=new_t;
        
    elif(length==2):
        start = args[0];
        duration = args[1];
        tili = [];
        durli= [];
        tili = start;
        sti1=tili.split(':');
        bhr=int(sti1[0]);
        sti2=sti1[1].split(' ');
        bmin=int(sti2[0]);
        bses=sti2[1];
        ases="AM"
        if(bses=="PM"):
            bhr=bhr+12;
        durli=duration;
        deli1=durli.split(':')
        dhr= int(deli1[0]);
        dmin= int(deli1[1]);
        addedmin= bmin+dmin;
        temp1=0
        if(addedmin>=60):
            temp1=addedmin//60;
            addedmin=addedmin%60;
        addedhr=temp1+bhr+dhr;
        temp3=0;
        if(addedhr>=24):
            temp3=addedhr//24;
            addedhr=addedhr%24;
        if(addedhr>11):
            if((addedhr>11)and(addedhr!=0)):
                ases="PM";
            addedhr=addedhr-12;
        noDay=temp3;
        if(addedhr==0):
            addedhr=12;
        ah=str(addedhr);
        am=str(addedmin).zfill(2);
        if(temp3==0):
            new_t=ah+':'+am+' '+ases;
        if(temp3==1):
            new_t= ah+':'+am+' '+ases+" (next day)";
        if(temp3>1):
            temp3=str(temp3);
            new_t=ah+':'+am+' '+ases+" ("+temp3+" days later)";
        new_time=new_t;
    return(new_time);