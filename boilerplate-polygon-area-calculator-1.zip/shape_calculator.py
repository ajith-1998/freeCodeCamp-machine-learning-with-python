class Rectangle:
    def __init__(self,width,height):
        self.width = width
        self.height = height

    def __str__(self):
        o = f"Rectangle(width={self.width}, height={self.height})";
        return o

    def set_width(self,width):
        self.width = width

    def set_height(self,height):
        self.height = height

    def get_area(self):
        return self.width*self.height

    def get_perimeter(self):
        return 2*self.height + 2*self.width
    
    def get_diagonal(self):
        return ((self.width ** 2 + self.height **2) ** 0.5)

    def get_picture(self):
        if((self.height<50)and(self.width<50)):
            self.s = ''
            for i in range(self.height):
                for j in range(self.width):
                    self.s= self.s+"*"
                self.s=self.s+'\n'
            return self.s
        else:
            self.s="Too big for picture."
            return self.s

    def get_amount_inside(self,shape):
        m1= self.height // shape.width
        m2= self.width // shape.height
        return m1*m2


    


class Square(Rectangle):

    def __init__(self,sidea):
        super().__init__(sidea,sidea)


    def __str__(self):
        o = f"Square(side={self.height})";
        return o

    def set_side(self, side):
        self.width = side
        self.height = side

    def set_width(self, side):
        self.width = side
        self.height = side

    def set_height(self, side):
        self.width = side
        self.height = side
